import { callLLM } from '@/lib/llm';

interface GatekeeperResult {
    needs_review: boolean;
    category: 'POLICY' | 'BIDDING' | 'AGREEMENT' | 'IGNORE';
    reason: string;
}

export async function runGatekeeper(fileName: string, textSummary: string, _keywordStats: Record<string, number>): Promise<GatekeeperResult> {
    console.log('Running Gatekeeper on:', fileName);

    const systemPrompt = `
    你是一个“公平竞争审查系统”的守门员（Gatekeeper）。你的任务是快速判断一份政府文件是否属于公平竞争审查的范畴，并对其进行分类。

    请根据文件名和文件前2000个字符的内容进行判断。

    分类标准如下：
    1. **BIDDING (招标采购)**: 涉及招标公告、采购文件、中标公示等。关键词：招标、采购、比选、竞争性谈判。
    2. **POLICY (产业政策)**: 涉及市场准入、产业发展、招商引资、奖补政策、考核办法等规范性文件。关键词：办法、通知、意见、规定、若干措施。
    3. **AGREEMENT (政企协议)**: 政府与特定企业签订的合作协议、投资协议、框架协议等。关键词：协议、合同、备忘录。
    4. **IGNORE (忽略)**: 纯粹的行政管理文件（如人事任免、党建活动、会议通知）、纯技术性文件，不涉及市场主体经济活动。

    请以 JSON 格式返回结果，格式如下：
    {
        "needs_review": boolean, // 是否需要审查。BIDDING, POLICY, AGREEMENT 通常为 true，IGNORE 为 false。
        "category": "POLICY" | "BIDDING" | "AGREEMENT" | "IGNORE",
        "reason": "简短的判断理由（50字以内）"
    }
    `;

    const userPrompt = `
    文件名: ${fileName}
    文件内容摘要:
    ${textSummary}
    `;

    const resultStr = await callLLM(systemPrompt, userPrompt, true);

    if (!resultStr) {
        // Fallback if LLM fails
        return {
            needs_review: true,
            category: 'POLICY', // Default to POLICY to be safe
            reason: 'AI分析失败，默认建议人工审查。'
        };
    }

    try {
        const result = JSON.parse(resultStr) as GatekeeperResult;
        return result;
    } catch (e) {
        console.error('Failed to parse Gatekeeper JSON:', resultStr);
        return {
            needs_review: true,
            category: 'POLICY',
            reason: 'AI返回格式错误，默认建议人工审查。'
        };
    }
}
