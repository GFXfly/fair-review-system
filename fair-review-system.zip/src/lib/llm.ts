import OpenAI from 'openai';

// Lazy load the client to ensure we pick up the latest env vars
function getDeepSeekClient() {
    const apiKey = process.env.DEEPSEEK_API_KEY;
    const baseURL = process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';

    if (!apiKey) {
        console.warn('DEEPSEEK_API_KEY is not set.');
    } else {
        // Debug log to confirm which key is being used (safe log)
        console.log(`[LLM] Initializing client with Key: ${apiKey.substring(0, 5)}...${apiKey.substring(apiKey.length - 4)}`);
    }

    return new OpenAI({
        apiKey: apiKey || 'dummy-key',
        baseURL: baseURL,
    });
}

export const DEEPSEEK_MODEL = 'deepseek-chat';
export const DEEPSEEK_REASONER_MODEL = 'deepseek-reasoner';

export async function callLLM(
    systemPrompt: string,
    userPrompt: string,
    jsonMode: boolean = false
): Promise<string | null> {
    const deepseek = getDeepSeekClient();

    // Add retry logic for auth errors or transient failures?
    // For now, just let it throw to visible error.

    try {
        const completion = await deepseek.chat.completions.create({
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt },
            ],
            model: DEEPSEEK_MODEL,
            response_format: jsonMode ? { type: 'json_object' } : { type: 'text' },
            temperature: 0.1,
        });

        return completion.choices[0].message.content;
    } catch (error: any) {
        console.error('[LLM] Call Failed:', error.message);
        if (error.status === 401) {
            console.error('[LLM] Authentication Error - Please check DEEPSEEK_API_KEY.');
        }
        throw error; // Re-throw to be handled by caller
    }
}


// Singleton for formatting/embedding pipeline
let embedder: any = null;

// New function to call SiliconFlow API
async function getSiliconFlowEmbedding(text: string): Promise<number[]> {
    const apiKey = process.env.SILICONFLOW_API_KEY || 'sk-gvmahzludywikpfxhuiyqswqxfcisofmeoqpumkqwjqqskdy';
    const baseUrl = 'https://api.siliconflow.cn/v1/embeddings';

    try {
        const response = await fetch(baseUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'BAAI/bge-m3', // Recommended model for Chinese text
                input: text
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`SiliconFlow API Error: ${response.status} - ${errorText}`);
        }

        const data = await response.json();
        if (data.data && data.data.length > 0) {
            return data.data[0].embedding;
        } else {
            throw new Error('No embedding data returned from API');
        }
    } catch (error: any) {
        console.error('[LLM] SiliconFlow Embedding Failed:', error.message);
        return [];
    }
}

export async function getEmbedding(text: string): Promise<number[]> {
    // Priority: Use SiliconFlow API if Key is present (or hardcoded for now as requested)
    return await getSiliconFlowEmbedding(text);

    /* 
    try {
        // TEMPORARY FIX: Disable local embedding on server to prevent Ort::Exception crash.
        // ... (Old local logic commented out)
    }
    */
}
