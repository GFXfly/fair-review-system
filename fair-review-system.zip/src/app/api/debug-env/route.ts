
import { NextResponse } from 'next/server';

export async function GET() {
    const key = process.env.DEEPSEEK_API_KEY || 'NOT_SET';
    return NextResponse.json({
        keyVisible: key.substring(0, 5) + '...' + key.substring(key.length - 4),
        keyLength: key.length,
        env: process.env.NODE_ENV
    });
}
