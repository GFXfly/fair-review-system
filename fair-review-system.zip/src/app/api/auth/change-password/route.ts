import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { cookies } from 'next/headers';

export async function POST(req: NextRequest) {
    try {
        const { currentPassword, newPassword } = await req.json();
        const cookieStore = await cookies();
        const userIdStr = cookieStore.get('userId')?.value;
        const userId = userIdStr ? parseInt(userIdStr) : null;

        if (!userId) {
            return NextResponse.json({ error: '未登录' }, { status: 401 });
        }

        if (!newPassword || newPassword.length < 6) {
            return NextResponse.json({ error: '新密码长度至少需6位' }, { status: 400 });
        }

        // 1. Find user
        const user = await prisma.user.findUnique({
            where: { id: userId }
        });

        if (!user) {
            return NextResponse.json({ error: '用户不存在' }, { status: 404 });
        }

        // 2. Verify current (plain text for now, as per login route)
        if (user.password !== currentPassword) {
            return NextResponse.json({ error: '当前密码错误' }, { status: 400 });
        }

        // 3. Update password
        await prisma.user.update({
            where: { id: userId },
            data: { password: newPassword }
        });

        return NextResponse.json({ success: true });

    } catch (error) {
        console.error('Change password error:', error);
        return NextResponse.json({ error: '修改失败' }, { status: 500 });
    }
}
