
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
    try {
        const users = await prisma.user.findMany({
            orderBy: { createdAt: 'desc' },
            select: {
                id: true,
                username: true,
                name: true,
                department: true,
                role: true,
                createdAt: true,
                // Exclude password
            },
        });
        return NextResponse.json(users);
    } catch (error) {
        console.error('Failed to fetch users:', error);
        return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { username, password, name, department, role } = body;

        // Manual validation
        if (!username || typeof username !== 'string' || username.length < 3) {
            return NextResponse.json({ error: 'Invalid username: must be at least 3 characters' }, { status: 400 });
        }
        if (!password || typeof password !== 'string' || password.length < 6) {
            return NextResponse.json({ error: 'Invalid password: must be at least 6 characters' }, { status: 400 });
        }
        if (!name || typeof name !== 'string') {
            return NextResponse.json({ error: 'Invalid name' }, { status: 400 });
        }
        const validRoles = ['user', 'admin'];
        const userRole = role && validRoles.includes(role) ? role : 'user';


        // Check if user already exists
        const existingUser = await prisma.user.findUnique({
            where: { username },
        });

        if (existingUser) {
            return NextResponse.json({ error: 'Username already exists' }, { status: 409 });
        }

        const newUser = await prisma.user.create({
            data: {
                username,
                password, // In a real app, hash this!
                name,
                department,
                role: userRole,
            },
        });

        // Remove password from response
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password: _, ...userWithoutPassword } = newUser;

        return NextResponse.json(userWithoutPassword, { status: 201 });
    } catch (error) {
        console.error('Failed to create user:', error);
        return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
    }
}
