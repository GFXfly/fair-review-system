import mammoth from 'mammoth';

export async function extractTextFromFile(file: File): Promise<string> {
    const buffer = Buffer.from(await file.arrayBuffer());
    const fileType = file.type;
    const fileName = file.name.toLowerCase();

    try {
        // 1. Support DOCX / WPS (Modern XML)
        if (
            fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
            fileName.endsWith('.docx') ||
            fileName.endsWith('.wps')
        ) {
            try {
                // Use convertToHtml to preserve structure like tables
                const result = await mammoth.convertToHtml({ buffer });
                let html = result.value;

                if (!html.trim()) {
                    console.warn(`Warning: Extracted text is empty for ${fileName}`);
                }

                // Custom HTML to Text mapping for Tables

                // 0. SPECIAL HANDLING: Flatten paragraphs INSIDE table rows first.
                // This ensures that a multi-line cell in Word becomes a single line in our text, 
                // preventing the table structure from being fragmented by newlines.
                html = html.replace(/<tr\b[^>]*>([\s\S]*?)<\/tr>/g, (match, content) => {
                    // Replace paragraph endings with a space (or special marker) inside rows
                    return `<tr>${content.replace(/<\/p>/g, " ")}</tr>`;
                });

                // 1. Replace cell endings with a separator
                html = html.replace(/<\/td>/g, "  |  ").replace(/<\/th>/g, "  |  ");
                // 2. Replace row endings with newlines
                html = html.replace(/<\/tr>/g, "\n");
                // 3. Replace paragraph endings with newlines
                html = html.replace(/<\/p>/g, "\n");
                // 4. Replace breaks
                html = html.replace(/<br\s*\/?>/g, "\n");
                // 5. Strip all other tags
                let text = html.replace(/<[^>]*>/g, "");

                // 6. Decode common entities
                text = text
                    .replace(/&nbsp;/g, " ")
                    .replace(/&amp;/g, "&")
                    .replace(/&lt;/g, "<")
                    .replace(/&gt;/g, ">")
                    .replace(/&quot;/g, '"');

                // 7. Clean up excessive newlines
                text = text.replace(/\n\s*\n/g, "\n\n").trim();

                // 7.1 Fix spaces between Chinese characters (common in justified text or OCR)
                // This converts "基 建 总 投 资" back to "基建总投资", preventing vertical rendering in narrow columns
                text = text.replace(/([\u4e00-\u9fa5])\s+([\u4e00-\u9fa5])/g, '$1$2');

                // 8. Add indentation (2 full-width spaces) for better readability
                // Note: We skip table rows (which we marked with |) to keep them aligned
                return text.split('\n').map(line => {
                    const trimmedLine = line.trim();
                    if (trimmedLine && !trimmedLine.includes('|')) {
                        return '\u3000\u3000' + trimmedLine;
                    }
                    return line; // Return original line (with its existing spacing if any) or empty
                }).join('\n');
            } catch (mammothError: any) {
                console.error('Mammoth extraction failed for:', fileName, mammothError);
                throw new Error(`无法解析 Word 文档 (${fileName})。可能原因：\n1. 文件虽然后缀是 .docx，但实际是旧版 .doc 格式；\n2. 文档被加密保护。\n\n建议您用 Word/WPS 打开文档，选择“另存为” .docx 格式后再上传。`);
            }
        }
        // 2. Support Plain Text
        else if (fileType === 'text/plain' || fileName.endsWith('.txt')) {
            const textDecoder = new TextDecoder('utf-8');
            return textDecoder.decode(buffer);
        }
        // 3. Fallback for others
        else {
            throw new Error(`不支持的文件格式: ${fileName}。目前系统仅支持 .docx (Word) 和 .txt 格式。`);
        }
    } catch (error: any) {
        console.error('Error parsing file:', error);
        throw new Error(error.message || `文件解析失败: ${fileName}`);
    }
}
