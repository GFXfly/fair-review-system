import { NextRequest, NextResponse } from 'next/server';
import { runGatekeeper } from '@/lib/agents/gatekeeper';
import { runAuditor } from '@/lib/agents/auditor';
import { runRiskRadar } from '@/lib/agents/radar';
import { runDefender, runJudge } from '@/lib/agents/debate';
import { runGuidanceCounselor } from '@/lib/agents/guidance_counselor';
import { extractTextFromFile } from '@/lib/file-parser';
import { PrismaClient } from '@prisma/client';
import { cookies } from 'next/headers';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
    try {
        const formData = await req.formData();
        const file = formData.get('file') as File;

        // Get user from cookie
        const cookieStore = await cookies();
        const userIdStr = cookieStore.get('userId')?.value;
        const userId = userIdStr ? parseInt(userIdStr) : null;

        if (!file) {
            return NextResponse.json({ error: 'No file provided' }, { status: 400 });
        }

        // Actual text extraction
        const fileName = file.name;
        let text = "";
        try {
            text = await extractTextFromFile(file);
            console.log(`Extracted ${text.length} characters from ${fileName}`);
        } catch (error: any) {
            console.error('Text extraction failed:', error);
            // Return specific error message from parser
            return NextResponse.json({
                error: '文件解析失败',
                details: error.message || '无法提取文件内容，请检查文件是否损坏或格式是否正确'
            }, { status: 400 });
        }

        // 1. Gatekeeper
        const gatekeeperResult = await runGatekeeper(fileName, text.substring(0, 2000), {});

        // Save ignored record
        if (!gatekeeperResult.needs_review) {
            const savedRecord = await prisma.reviewRecord.create({
                data: {
                    fileName: fileName,
                    fileSize: file.size,
                    status: 'ignored',
                    summary: `【无需审查】${gatekeeperResult.reason}`,
                    riskCount: 0,
                    userId: userId
                }
            });

            return NextResponse.json({
                id: savedRecord.id,
                gatekeeper: gatekeeperResult,
                auditor: [],
                radar: null
            });
        }

        // 1.5 Guidance Counselor (Fetch expert Q&A)
        const guidance = await runGuidanceCounselor(text);

        // 2. Auditor
        const auditorResults = await runAuditor(gatekeeperResult.category, text, guidance);

        // --- NEW: Debate Agents Loop ---
        console.log('[Debate] Starting debate loop for', auditorResults.length, 'risks');
        const refinedRisks: any[] = [];

        for (const risk of auditorResults) {
            // Only debate High/Medium risks to save time/tokens? Or all? Let's do all for now.
            console.log(`[Debate] Defending risk: ${risk.description.substring(0, 30)}...`);

            // Step 1: Defender
            const defenseArgs = await runDefender(risk, text);
            console.log(`[Debate] Defense: ${defenseArgs.substring(0, 50)}...`);

            // Step 2: Judge
            const finalVerdict = await runJudge(risk, defenseArgs);

            if (finalVerdict) {
                console.log(`[Debate] Judge Verdict: MAINTAIN/DOWNGRADE`);
                refinedRisks.push(finalVerdict);
            } else {
                console.log(`[Debate] Judge Verdict: DISMISS`);
            }
        }

        // Use refined risks for Radar and Database
        const finalRisks = refinedRisks;

        // 3. Risk Radar (only if High risk in Bidding)
        let radarAlert = null;
        const hasHighRisk = finalRisks.some(r => r.risk_level === 'High');
        if (gatekeeperResult.category === 'BIDDING' && hasHighRisk) {
            radarAlert = await runRiskRadar(fileName, finalRisks);
        }

        // Save completed record
        const savedRecord = await prisma.reviewRecord.create({
            data: {
                fileName: fileName,
                fileSize: file.size,
                status: 'completed', // Or 'failed' if we caught errors
                summary: `文件类型：${gatekeeperResult.category}。AI 判定理由：${gatekeeperResult.reason}`,
                riskCount: finalRisks.length,
                userId: userId,
                risks: {
                    create: finalRisks.map(r => ({
                        level: r.risk_level,
                        type: '合规风险', // Default or derived
                        title: r.description.substring(0, 50),
                        description: r.description,
                        location: r.location,
                        suggestion: r.suggestion
                    }))
                }
            }
        });

        return NextResponse.json({
            id: savedRecord.id,
            gatekeeper: gatekeeperResult,
            auditor: finalRisks,
            radar: radarAlert,
            text: text // Return the extracted text
        });

    } catch (error: any) {
        console.error('Analysis failed:', error);
        return NextResponse.json({
            error: 'Analysis failed',
            details: error.message || String(error)
        }, { status: 500 });
    }
}
