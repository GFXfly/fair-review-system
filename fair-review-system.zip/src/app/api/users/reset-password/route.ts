
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
    try {
        const { userId, newPassword } = await request.json();

        if (!userId) {
            return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
        }

        if (!newPassword || newPassword.length < 6) {
            return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
        }

        // Check if user exists
        const user = await prisma.user.findUnique({
            where: { id: userId }
        });

        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        // Update password
        await prisma.user.update({
            where: { id: userId },
            data: { password: newPassword }
        });

        return NextResponse.json({ success: true });

    } catch (error) {
        console.error('Failed to reset password:', error);
        return NextResponse.json({ error: 'Failed to reset password' }, { status: 500 });
    }
}
