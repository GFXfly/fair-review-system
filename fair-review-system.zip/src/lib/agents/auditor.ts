import { callLLM } from '@/lib/llm';
import { searchSimilarCases, searchSimilarRegulations } from '@/lib/rag';

export interface AuditIssue {
    id: string;
    risk_level: 'High' | 'Medium' | 'Low';
    description: string;
    location: string; // Quote from the text
    suggestion: string;
    reference?: string; // Reference to similar case or regulation
    violated_law: string; // Specific article, e.g., "《公平竞争审查条例》第十条第一款"
}

export async function runAuditor(category: string, text: string, guidance: string = ""): Promise<AuditIssue[]> {
    console.log('Running Auditor on category:', category);

    // 1. Sliding Window RAG Retrieval: Scan full text for relevant knowledge
    const windowSize = 1000;
    const overlap = 200;
    const collectedCases = new Map<number, any>();
    const collectedRegs = new Map<number, any>();

    // Limit to first 10000 chars to avoid excessive API calls if doc is huge, 
    // or just chunk the whole thing. Let's cap at 5 chunks for performance efficiency.
    const maxChunks = 5;
    let chunksProcessed = 0;

    for (let i = 0; i < text.length && chunksProcessed < maxChunks; i += (windowSize - overlap)) {
        const chunk = text.substring(i, i + windowSize);
        if (chunk.length < 100) break; // Skip small trailing chunks

        const [cases, regs] = await Promise.all([
            searchSimilarCases(chunk, 2), // Top 2 per chunk
            searchSimilarRegulations(chunk, 1) // Top 1 per chunk
        ]);

        cases.forEach((c: any) => collectedCases.set(c.id, c));
        regs.forEach((r: any) => collectedRegs.set(r.id, r));

        chunksProcessed++;
    }

    // Convert Maps to Arrays and limit total context
    const uniqueCases = Array.from(collectedCases.values()).slice(0, 5); // Max 5 unique cases
    const uniqueRegs = Array.from(collectedRegs.values()).slice(0, 3);   // Max 3 unique regs

    let ragContext = "";

    if (uniqueCases.length > 0) {
        ragContext += "\n参考历史违规案例（请重点比对并在 reference 字段中详细引用）：\n";
        uniqueCases.forEach((c, idx) => {
            // 提供更完整的案例信息
            ragContext += `${idx + 1}. 【${c.violationType}】${c.title}\n`;
            ragContext += `   案情：${c.content.substring(0, 300)}...\n`;
            ragContext += `   处理结果：${c.result || '未知'}\n`;
            if (c.violationDetail) {
                ragContext += `   违规要点：${c.violationDetail}\n`;
            }
            ragContext += `\n`;
        });
    }

    if (uniqueRegs.length > 0) {
        ragContext += "\n相关法律法规依据（请在 violated_law 字段中完整引用具体条款）：\n";
        uniqueRegs.forEach((r, idx) => {
            // 提供更完整的法规内容，以便 AI 能够引用具体条款
            ragContext += `${idx + 1}. 《${r.title}》\n`;
            ragContext += `   内容：${r.content ? r.content.substring(0, 1000) : '暂无'}...\n\n`;
        });
    }

    const systemPrompt = `
    你是一个资深的"公平竞争审查"审计员（Auditor）。你的任务是根据《公平竞争审查条例》及相关法律法规，审查政府文件是否存在排除、限制竞争的内容。

    当前的审查类别是：${category}。

    审查重点：
    1. **市场准入和退出**: 是否设置不合理的准入壁垒？是否设置不合理的审批前置条件？
    2. **商品和要素自由流动**: 是否限制外地商品、服务进入本地市场？是否排斥外地经营者参与本地招标投标？
    3. **影响生产经营成本**: 是否给予特定经营者税收优惠、财政补贴（除非法律规定）？是否要求企业缴纳不合理的保证金？
    4. **影响生产经营行为**: 是否强制企业从事《反垄断法》禁止的垄断行为？是否干预实行市场调节价的商品价格？

    参考知识库信息：
    ${guidance}

    ${ragContext}

    请仔细阅读文件内容，找出所有潜在的风险点。如果文件内容与上述历史违规案例如出一辙，请务必标记为 High 风险。

    **重要要求**：
    1. violated_law 字段必须包含完整的法条内容，格式为："《法规名称》第X条第X款：【完整法条原文】"
    2. reference 字段如果引用案例，必须包含案例的详细情况，格式为："【案例标题】案情：XXX。处理结果：XXX。"
    3. 如果知识库中提供了相关法规和案例，请优先引用；如果没有，请根据你的法律知识补充。

    请以 JSON 数组格式返回结果，每个风险点包含以下字段：
    [
        {
            "id": "risk_1",
            "risk_level": "High" | "Medium" | "Low",
            "description": "详细描述风险点，解释为什么违规。",
            "violated_law": "必须包含完整法条。格式：《法规名称》第X条第X款：【完整法条原文内容】",
            "location": "原文引用（20字左右），用于定位。",
            "suggestion": "具体的修改建议。",
            "reference": "如有相似案例，格式：【案例标题】案情：XXX。违规要点：XXX。处理结果：XXX。"
        }
    ]

    如果未发现风险，请返回空数组 []。
    `;

    // Truncate text to avoid token limits
    const truncatedText = text.substring(0, 15000);

    const userPrompt = `
    文件内容：
    ${truncatedText}
    `;

    const resultStr = await callLLM(systemPrompt, userPrompt, true);

    if (!resultStr) {
        return [];
    }

    try {
        const issues = JSON.parse(resultStr) as AuditIssue[];
        // Ensure IDs are unique
        return issues.map((issue, index) => ({ ...issue, id: `risk_${Date.now()}_${index}` }));
    } catch (e) {
        console.error('Failed to parse Auditor JSON:', resultStr);
        return [];
    }
}
